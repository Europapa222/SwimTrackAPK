package ru.swimtrack.app

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private data class Goal(
    val pb: SwimResult,
    val currentIdx: Int,
    val targetIdx: Int,
    val targetCs: Int,
    val gapCs: Int,
    val progress: Float
)

@Composable
fun HomeScreen(vm: SwimViewModel, onAdd: () -> Unit, onDiary: () -> Unit) {
    val pbs = vm.personalBests()
    val bestByPoints = pbs.maxByOrNull { vm.points(it) ?: -1 }
    val bestRankIdx = pbs.mapNotNull { vm.rank(it) }.filter { it >= 0 }.minOrNull()
    val last = vm.results.maxByOrNull { it.epochDay * 1_000_000 + (it.id % 1_000_000) }

    val goals = pbs.mapNotNull { pb ->
        val norm = vm.tables.norm(vm.sex, pb.event) ?: return@mapNotNull null
        val cur = vm.tables.rankIndex(vm.sex, pb.event, pb.timeCs) ?: return@mapNotNull null
        val target = if (cur == -1) 8 else cur - 1
        if (target < 0) return@mapNotNull null
        val t = norm[target]
        Goal(pb, cur, target, t, pb.timeCs - t, (t.toFloat() / pb.timeCs).coerceIn(0f, 1f))
    }.sortedByDescending { it.progress }.take(4)

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            GradientCard(AquaBrush) {
                Text(
                    if (vm.name.isBlank()) "Привет, пловец! 🏊" else "Привет, ${vm.name}! 🏊",
                    color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    if (vm.results.isEmpty()) "Добавь первый заплыв — посчитаю очки и разряд"
                    else "Заплывов в дневнике: ${vm.results.size} · дистанций: ${pbs.size}",
                    color = Color.White.copy(alpha = 0.9f)
                )
                Spacer(Modifier.height(12.dp))
                Button(onClick = onAdd) { Text("Записать заплыв") }
            }
        }

        item { ProfileCard(vm) }

        if (vm.results.isNotEmpty()) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    GradientCard(SunsetBrush, Modifier.weight(1f)) {
                        Text("Лучшие очки", color = Color.White.copy(alpha = 0.9f), fontSize = 12.sp)
                        Text(
                            "${bestByPoints?.let { vm.points(it) } ?: "—"}",
                            color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold
                        )
                        Text(bestByPoints?.event?.title ?: "", color = Color.White.copy(alpha = 0.9f), fontSize = 12.sp)
                    }
                    GradientCard(VioletBrush, Modifier.weight(1f)) {
                        Text("Высший разряд", color = Color.White.copy(alpha = 0.9f), fontSize = 12.sp)
                        Text(
                            if (bestRankIdx != null) RANKS[bestRankIdx] else "—",
                            color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold
                        )
                        Text("по личным рекордам", color = Color.White.copy(alpha = 0.9f), fontSize = 12.sp)
                    }
                }
            }
            last?.let { r ->
                item {
                    SoftCard(onClick = onDiary) {
                        Text("Последний заплыв", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(r.event.title, fontWeight = FontWeight.SemiBold)
                                Text(
                                    "${formatDate(r.epochDay)} · бассейн ${r.event.pool} м",
                                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(formatTime(r.timeCs), fontSize = 22.sp, fontWeight = FontWeight.Bold)
                                RankChip(rankText(vm.rank(r)), rankColor(vm.rank(r)))
                            }
                        }
                    }
                }
            }
        }

        if (goals.isNotEmpty()) {
            item {
                Text("Ближайшие цели", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
            items(goals) { g -> GoalCard(g) }
        }
    }
}

@Composable
private fun GoalCard(g: Goal) {
    val anim by animateFloatAsState(g.progress, tween(900), label = "goal")
    SoftCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(g.pb.event.title, fontWeight = FontWeight.SemiBold)
                Text(
                    "бассейн ${g.pb.event.pool} м · рекорд ${formatTime(g.pb.timeCs)}",
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            RankChip(rankText(g.currentIdx), rankColor(g.currentIdx))
            Text("  →  ")
            RankChip(RANKS[g.targetIdx], rankColor(g.targetIdx))
        }
        Spacer(Modifier.height(10.dp))
        LinearProgressIndicator(
            progress = { anim },
            modifier = Modifier.fillMaxWidth().height(8.dp),
            color = rankColor(g.targetIdx)
        )
        Spacer(Modifier.height(6.dp))
        Text(
            "Норматив ${RANKS[g.targetIdx]}: ${formatTime(g.targetCs)} — осталось ${formatGap(g.gapCs)}",
            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun ProfileCard(vm: SwimViewModel) {
    SoftCard {
        Text("Профиль", fontWeight = FontWeight.Bold)
        Text(
            "Пол нужен, чтобы выбрать нужные нормативы и базовые времена.",
            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = vm.name,
            onValueChange = { vm.setNameValue(it.take(30)) },
            label = { Text("Имя") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Sex.entries.forEach { s ->
                FilterChip(
                    selected = vm.sex == s,
                    onClick = { vm.setSexValue(s) },
                    label = { Text(s.ru) }
                )
            }
        }
    }
}

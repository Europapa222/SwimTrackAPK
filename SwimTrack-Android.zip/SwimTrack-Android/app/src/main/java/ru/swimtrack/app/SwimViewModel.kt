package ru.swimtrack.app

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import org.json.JSONArray
import org.json.JSONObject

class SwimViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("swimtrack", Context.MODE_PRIVATE)

    val tables: Tables = Tables.load(app)
    val results = mutableStateListOf<SwimResult>()

    var sex by mutableStateOf(Sex.M)
        private set
    var name by mutableStateOf("")
        private set

    init {
        sex = if (prefs.getString("sex", "M") == "F") Sex.F else Sex.M
        name = prefs.getString("name", "") ?: ""
        runCatching {
            val arr = JSONArray(prefs.getString("results", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                results.add(
                    SwimResult(
                        id = o.getLong("id"),
                        epochDay = o.getLong("d"),
                        event = EventKey(o.getInt("pool"), Style.fromCode(o.getString("style")), o.getInt("dist")),
                        timeCs = o.getInt("cs"),
                        place = o.optString("place", ""),
                        note = o.optString("note", "")
                    )
                )
            }
        }
    }

    private fun persist() {
        val arr = JSONArray()
        results.forEach { r ->
            arr.put(
                JSONObject()
                    .put("id", r.id)
                    .put("d", r.epochDay)
                    .put("pool", r.event.pool)
                    .put("style", r.event.style.code)
                    .put("dist", r.event.dist)
                    .put("cs", r.timeCs)
                    .put("place", r.place)
                    .put("note", r.note)
            )
        }
        prefs.edit().putString("results", arr.toString()).apply()
    }

    fun setSexValue(s: Sex) {
        sex = s
        prefs.edit().putString("sex", s.code).apply()
    }

    fun setNameValue(n: String) {
        name = n
        prefs.edit().putString("name", n).apply()
    }

    fun add(r: SwimResult) {
        results.add(r)
        persist()
    }

    fun update(r: SwimResult) {
        val i = results.indexOfFirst { it.id == r.id }
        if (i >= 0) results[i] = r else results.add(r)
        persist()
    }

    fun delete(id: Long) {
        results.removeAll { it.id == id }
        persist()
    }

    fun points(r: SwimResult): Int? = tables.points(sex, r.event, r.timeCs)

    fun rank(r: SwimResult): Int? = tables.rankIndex(sex, r.event, r.timeCs)

    fun personalBests(): List<SwimResult> =
        results.groupBy { it.event }.map { (_, l) -> l.minBy { it.timeCs } }

    fun exportCsv(): String {
        val sb = StringBuilder("Дата;Бассейн;Дистанция;Время;Очки;Разряд;Соревнование;Заметка\n")
        results.sortedBy { it.epochDay }.forEach { r ->
            sb.append(formatDate(r.epochDay)).append(';')
                .append(r.event.pool).append(';')
                .append(r.event.title).append(';')
                .append(formatTime(r.timeCs)).append(';')
                .append(points(r) ?: "").append(';')
                .append(rankText(rank(r))).append(';')
                .append(r.place.replace(';', ',')).append(';')
                .append(r.note.replace(';', ',').replace('\n', ' ')).append('\n')
        }
        return sb.toString()
    }
}

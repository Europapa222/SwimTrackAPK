package ru.swimtrack.app

import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** «Твой дневник» — все данные в одном месте: рекорды, история заплывов, экспорт. */
@Composable
fun DiaryScreen(vm: SwimViewModel, onEdit: (Long) -> Unit) {
    val ctx = LocalContext.current
    var section by remember { mutableIntStateOf(0) } // 0 — рекорды, 1 — все заплывы
    var filter by remember { mutableStateOf<EventKey?>(null) }
    var expanded by remember { mutableStateOf<Long?>(null) }
    var toDelete by remember { mutableStateOf<SwimResult?>(null) }

    val events = vm.results.map { it.event }.distinct()
        .sortedWith(compareBy({ it.pool }, { it.style.ordinal }, { it.dist }))
    val activeFilter = filter?.takeIf { it in events }
    val pbs = vm.personalBests()
        .filter { activeFilter == null || it.event == activeFilter }
        .sortedWith(compareBy({ it.event.pool }, { it.event.style.ordinal }, { it.event.dist }))
    val all = vm.results
        .filter { activeFilter == null || it.event == activeFilter }
        .sortedByDescending { it.epochDay * 1_000_000 + (it.id % 1_000_000) }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("Твой дневник", fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text(
                "Все твои заплывы, рекорды и разряды в одном месте.",
                color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp
            )
        }

        item {
            GradientCard(MintBrush) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                    Summary("Заплывов", "${vm.results.size}")
                    Summary("Дистанций", "${events.size}")
                    Summary("Лучшие очки", "${vm.personalBests().maxOfOrNull { vm.points(it) ?: 0 } ?: 0}")
                }
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = section == 0, onClick = { section = 0 }, label = { Text("Личные рекорды") })
                FilterChip(selected = section == 1, onClick = { section = 1 }, label = { Text("Все заплывы") })
            }
        }

        if (events.isNotEmpty()) {
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    item {
                        FilterChip(selected = activeFilter == null, onClick = { filter = null }, label = { Text("Все") })
                    }
                    items(events) { e ->
                        FilterChip(
                            selected = e == activeFilter,
                            onClick = { filter = e },
                            label = { Text("${e.style.ru} ${e.dist} · ${e.pool}") }
                        )
                    }
                }
            }
        }

        if (vm.results.isEmpty()) {
            item {
                SoftCard {
                    Text("Дневник пока пуст", fontWeight = FontWeight.Bold)
                    Text(
                        "Открой вкладку «Заплыв» и запиши первый результат.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else if (section == 0) {
            items(pbs, key = { "pb" + it.id }) { r ->
                SoftCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(r.event.title, fontWeight = FontWeight.SemiBold)
                            Text(
                                "бассейн ${r.event.pool} м · ${formatDate(r.epochDay)}",
                                fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(formatTime(r.timeCs), fontSize = 22.sp, fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                RankChip("${vm.points(r) ?: "—"} оч.", MaterialTheme.colorScheme.primary)
                                RankChip(rankText(vm.rank(r)), rankColor(vm.rank(r)))
                            }
                        }
                    }
                }
            }
        } else {
            items(all, key = { it.id }) { r ->
                val open = expanded == r.id
                SoftCard(onClick = { expanded = if (open) null else r.id }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(r.event.title, fontWeight = FontWeight.SemiBold)
                            Text(
                                "${formatDate(r.epochDay)} · бассейн ${r.event.pool} м",
                                fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(formatTime(r.timeCs), fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                RankChip("${vm.points(r) ?: "—"} оч.", MaterialTheme.colorScheme.primary)
                                RankChip(rankText(vm.rank(r)), rankColor(vm.rank(r)))
                            }
                        }
                    }
                    AnimatedVisibility(open) {
                        Column {
                            Spacer(Modifier.height(8.dp))
                            if (r.place.isNotBlank()) Text("📍 ${r.place}", fontSize = 13.sp)
                            if (r.note.isNotBlank()) Text("📝 ${r.note}", fontSize = 13.sp)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { onEdit(r.id) }) { Text("Изменить") }
                                OutlinedButton(onClick = { toDelete = r }) { Text("Удалить", color = Color(0xFFD93025)) }
                            }
                        }
                    }
                }
            }
        }

        if (vm.results.isNotEmpty()) {
            item {
                OutlinedButton(
                    onClick = {
                        val i = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_SUBJECT, "SwimTrack — дневник")
                            putExtra(Intent.EXTRA_TEXT, vm.exportCsv())
                        }
                        ctx.startActivity(Intent.createChooser(i, "Экспорт дневника (CSV)"))
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("📤 Экспортировать дневник (CSV)") }
            }
        }
    }

    toDelete?.let { r ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Удалить заплыв?") },
            text = { Text("${r.event.title}, ${formatTime(r.timeCs)} от ${formatDate(r.epochDay)}") },
            confirmButton = {
                TextButton(onClick = { vm.delete(r.id); toDelete = null; expanded = null }) { Text("Удалить") }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Отмена") } }
        )
    }
}

@Composable
private fun Summary(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text(label, color = Color.White.copy(alpha = 0.9f), fontSize = 12.sp)
    }
}

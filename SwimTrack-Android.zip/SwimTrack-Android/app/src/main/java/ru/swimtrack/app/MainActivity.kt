package ru.swimtrack.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SwimTheme { App() }
        }
    }
}

@Composable
fun App(vm: SwimViewModel = viewModel()) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var editingId by rememberSaveable { mutableStateOf<Long?>(null) }
    val tabs = listOf("Главная" to "🏠", "Заплыв" to "➕", "Прогресс" to "📈", "Твой дневник" to "📒")

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { i, (label, emoji) ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = {
                            if (i != 1) editingId = null
                            tab = i
                        },
                        icon = { Text(emoji, fontSize = 20.sp) },
                        label = { Text(label, fontSize = 11.sp, maxLines = 1) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad)) {
            when (tab) {
                0 -> HomeScreen(vm, onAdd = { editingId = null; tab = 1 }, onDiary = { tab = 3 })
                1 -> AddScreen(
                    vm = vm,
                    editing = editingId?.let { id -> vm.results.firstOrNull { it.id == id } },
                    onDone = { editingId = null; tab = 3 }
                )
                2 -> ProgressScreen(vm)
                else -> DiaryScreen(vm, onEdit = { id -> editingId = id; tab = 1 })
            }
        }
    }
}

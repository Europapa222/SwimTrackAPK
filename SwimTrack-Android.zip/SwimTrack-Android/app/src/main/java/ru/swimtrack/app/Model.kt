package ru.swimtrack.app

import android.content.Context
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import kotlin.math.floor
import kotlin.math.pow

enum class Sex(val ru: String, val code: String) {
    M("Мужчины", "M"),
    F("Женщины", "F")
}

enum class Style(val code: String, val ru: String) {
    FREE("FREE", "Вольный стиль"),
    BACK("BACK", "На спине"),
    BREAST("BREAST", "Брасс"),
    FLY("FLY", "Баттерфляй"),
    IM("IM", "Комплекс");

    companion object {
        fun fromCode(c: String): Style = entries.first { it.code == c }
    }
}

data class EventKey(val pool: Int, val style: Style, val dist: Int) {
    val title: String get() = "${style.ru} $dist м"
    val full: String get() = "$title · бассейн $pool м"
}

/** Время хранится в сотых долях секунды. */
data class SwimResult(
    val id: Long,
    val epochDay: Long,
    val event: EventKey,
    val timeCs: Int,
    val place: String,
    val note: String
)

val RANKS = listOf("МСМК", "МС", "КМС", "I", "II", "III", "Iюн", "IIюн", "IIIюн")

fun rankText(idx: Int?): String = when {
    idx == null -> "нет норматива"
    idx < 0 -> "без разряда"
    else -> RANKS[idx]
}

fun formatTime(cs: Int): String {
    val m = cs / 6000
    val s = (cs % 6000) / 100
    val h = cs % 100
    return if (m > 0) "%d:%02d.%02d".format(m, s, h) else "%d.%02d".format(s, h)
}

fun formatGap(cs: Int): String = "%.2f с".format(cs / 100.0)

fun formatDate(epochDay: Long): String =
    LocalDate.ofEpochDay(epochDay).format(DateTimeFormatter.ofPattern("dd.MM.yyyy"))

fun formatDateShort(epochDay: Long): String =
    LocalDate.ofEpochDay(epochDay).format(DateTimeFormatter.ofPattern("dd.MM.yy"))

/** Таблицы нормативов ЕВСК и базовых времён World Aquatics (лежат в assets). */
class Tables(
    private val norms: Map<String, IntArray>,
    private val bases: Map<String, DoubleArray>
) {
    fun norm(sex: Sex, e: EventKey): IntArray? =
        norms["${e.pool}|${sex.code}|${e.style.code}|${e.dist}"]

    fun base(sex: Sex, e: EventKey): Double? =
        bases["${e.pool}|${e.style.code}|${e.dist}"]?.get(if (sex == Sex.M) 0 else 1)

    fun events(pool: Int): List<EventKey> =
        bases.keys.mapNotNull { k ->
            val p = k.split("|")
            if (p[0].toInt() == pool) EventKey(pool, Style.fromCode(p[1]), p[2].toInt()) else null
        }

    fun distances(pool: Int, style: Style): List<Int> =
        events(pool).filter { it.style == style }.map { it.dist }.sorted()

    /** Очки World Aquatics: floor(1000 * (база / время)^3). */
    fun points(sex: Sex, e: EventKey, cs: Int): Int? {
        val b = base(sex, e) ?: return null
        if (cs <= 0) return null
        return floor(1000.0 * (b / (cs / 100.0)).pow(3.0)).toInt()
    }

    /** null — нет норматива, -1 — разряд не выполнен, иначе индекс в RANKS. */
    fun rankIndex(sex: Sex, e: EventKey, cs: Int): Int? {
        val n = norm(sex, e) ?: return null
        for (i in n.indices) if (cs <= n[i]) return i
        return -1
    }

    companion object {
        fun load(ctx: Context): Tables {
            val norms = HashMap<String, IntArray>()
            ctx.assets.open("norms.csv").bufferedReader(Charsets.UTF_8).useLines { seq ->
                seq.drop(1).filter { it.isNotBlank() }.forEach { line ->
                    val p = line.trim().split(",")
                    val key = "${p[0]}|${p[1]}|${p[2]}|${p[3]}"
                    norms[key] = IntArray(9) { i -> Math.round(p[4 + i].toDouble() * 100).toInt() }
                }
            }
            val bases = HashMap<String, DoubleArray>()
            ctx.assets.open("base_times.csv").bufferedReader(Charsets.UTF_8).useLines { seq ->
                seq.drop(1).filter { it.isNotBlank() }.forEach { line ->
                    val p = line.trim().split(",")
                    bases["${p[0]}|${p[1]}|${p[2]}"] = doubleArrayOf(p[3].toDouble(), p[4].toDouble())
                }
            }
            return Tables(norms, bases)
        }
    }
}

package ru.swimtrack.app

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

data class ChartPoint(val x: Float, val y: Float)
data class ChartLine(val y: Float, val label: String, val color: Color)

private class Geom(
    val width: Float, val height: Float,
    val left: Float, val right: Float, val top: Float, val bottom: Float,
    val xMin: Float, val xMax: Float, val yMin: Float, val yMax: Float,
    val lowerIsBetter: Boolean
) {
    val w get() = width - left - right
    val h get() = height - top - bottom
    fun px(x: Float): Float = if (xMax == xMin) left + w / 2 else left + (x - xMin) / (xMax - xMin) * w
    fun py(y: Float): Float =
        if (lowerIsBetter) top + (y - yMin) / (yMax - yMin) * h
        else top + (yMax - y) / (yMax - yMin) * h
}

@Composable
fun LineChart(
    points: List<ChartPoint>,
    lines: List<ChartLine>,
    lowerIsBetter: Boolean,
    yLabel: (Float) -> String,
    selected: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val tm = rememberTextMeasurer()
    val primary = MaterialTheme.colorScheme.primary
    val gridColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)
    val labelStyle = TextStyle(fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    val surface = MaterialTheme.colorScheme.surface

    val ys = points.map { it.y } + lines.map { it.y }
    val lo = ys.min()
    val hi = ys.max()
    val pad = if (hi - lo < 1e-3f) 1f else (hi - lo) * 0.12f
    val yMin = lo - pad
    val yMax = hi + pad
    val xs = points.map { it.x }
    val xMin = if (xs.min() == xs.max()) xs.min() - 1 else xs.min()
    val xMax = if (xs.min() == xs.max()) xs.max() + 1 else xs.max()

    val reveal = remember(points) { Animatable(0f) }
    LaunchedEffect(points) {
        reveal.snapTo(0f)
        reveal.animateTo(1f, tween(800))
    }

    fun geom(wPx: Float, hPx: Float, d: Float) = Geom(
        wPx, hPx, 52f * d, 46f * d, 10f * d, 24f * d, xMin, xMax, yMin, yMax, lowerIsBetter
    )

    Canvas(
        modifier.pointerInput(points) {
            detectTapGestures { off ->
                val g = geom(size.width.toFloat(), size.height.toFloat(), density)
                var best = 0
                var bd = Float.MAX_VALUE
                points.forEachIndexed { i, p ->
                    val d = abs(g.px(p.x) - off.x)
                    if (d < bd) { bd = d; best = i }
                }
                onSelect(best)
            }
        }
    ) {
        val g = geom(size.width, size.height, density)

        // сетка и подписи оси Y
        for (i in 0..4) {
            val v = yMin + (yMax - yMin) * i / 4f
            val y = g.py(v)
            drawLine(gridColor, Offset(g.left, y), Offset(g.left + g.w, y), 1.dp.toPx())
            val txt = yLabel(v)
            val lay = tm.measure(txt, labelStyle)
            drawText(lay, topLeft = Offset(g.left - lay.size.width - 6.dp.toPx(), y - lay.size.height / 2f))
        }

        // линии нормативов
        lines.forEach { l ->
            val y = g.py(l.y)
            drawLine(
                l.color, Offset(g.left, y), Offset(g.left + g.w, y), 1.5.dp.toPx(),
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 10f))
            )
            val lay = tm.measure(l.label, TextStyle(fontSize = 10.sp, color = l.color, fontWeight = FontWeight.Bold))
            drawText(lay, topLeft = Offset(g.left + g.w + 6.dp.toPx(), y - lay.size.height / 2f))
        }

        // подписи оси X: первая и последняя даты
        val first = points.first()
        val last = points.last()
        val l1 = tm.measure(formatDateShort(first.x.toLong()), labelStyle)
        drawText(l1, topLeft = Offset(g.px(first.x) - l1.size.width / 2f, g.top + g.h + 4.dp.toPx()))
        if (points.size > 1) {
            val l2 = tm.measure(formatDateShort(last.x.toLong()), labelStyle)
            drawText(l2, topLeft = Offset(g.px(last.x) - l2.size.width / 2f, g.top + g.h + 4.dp.toPx()))
        }

        // линия результатов
        val path = Path()
        points.forEachIndexed { i, p ->
            val x = g.px(p.x)
            val y = g.py(p.y)
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        if (points.size > 1) {
            drawPath(path, primary.copy(alpha = reveal.value), style = Stroke(width = 3.dp.toPx()))
        }
        points.forEachIndexed { i, p ->
            val c = Offset(g.px(p.x), g.py(p.y))
            val sel = i == selected
            val r = (if (sel) 8.dp.toPx() else 5.dp.toPx()) * reveal.value
            drawCircle(primary, r, c)
            drawCircle(surface, r * 0.5f, c)
            if (sel) drawCircle(primary.copy(alpha = 0.25f), 14.dp.toPx() * reveal.value, c)
        }
    }
}

@Composable
fun ProgressScreen(vm: SwimViewModel) {
    val events = vm.results.map { it.event }.distinct()
        .sortedWith(compareBy({ it.pool }, { it.style.ordinal }, { it.dist }))

    if (events.isEmpty()) {
        Column(
            Modifier.fillMaxWidth().padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(48.dp))
            Text("📈", fontSize = 56.sp)
            Text("Пока нечего показывать", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(
                "Добавь хотя бы один заплыв — здесь появится график прогресса.",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        return
    }

    var chosen by remember { mutableStateOf<EventKey?>(null) }
    val ev = chosen?.takeIf { it in events } ?: events.first()
    var mode by remember { mutableIntStateOf(0) } // 0 — время, 1 — очки
    var sel by remember(ev) { mutableIntStateOf(-1) }

    val list = vm.results.filter { it.event == ev }.sortedBy { it.epochDay }
    val norm = vm.tables.norm(vm.sex, ev)
    val pts = list.map { r ->
        ChartPoint(
            r.epochDay.toFloat(),
            if (mode == 0) r.timeCs / 100f else (vm.points(r) ?: 0).toFloat()
        )
    }

    val lines: List<ChartLine> = if (mode == 0 && norm != null) {
        val dataMin = pts.minOf { it.y }
        val dataMax = pts.maxOf { it.y }
        val bestCs = list.minOf { it.timeCs }
        val cur = vm.tables.rankIndex(vm.sex, ev, bestCs) ?: -1
        val target = if (cur == -1) 8 else cur - 1
        norm.indices.filter { i ->
            val v = norm[i] / 100f
            i == target || (v >= dataMin * 0.93f && v <= dataMax * 1.07f)
        }.map { i -> ChartLine(norm[i] / 100f, RANKS[i], rankColor(i)) }
    } else emptyList()

    val selIdx = if (sel in pts.indices) sel else pts.lastIndex
    val selR = list[selIdx]

    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Прогресс", fontSize = 24.sp, fontWeight = FontWeight.Bold)

        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(events) { e ->
                FilterChip(
                    selected = e == ev,
                    onClick = { chosen = e },
                    label = { Text("${e.style.ru} ${e.dist} · ${e.pool}") }
                )
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = mode == 0, onClick = { mode = 0 }, label = { Text("Время") })
            FilterChip(selected = mode == 1, onClick = { mode = 1 }, label = { Text("Очки FINA") })
        }

        SoftCard {
            Text(ev.full, fontWeight = FontWeight.SemiBold)
            Text(
                if (mode == 0) "Выше — быстрее. Пунктир — нормативы разрядов."
                else "Выше — больше очков. Нажми на точку, чтобы увидеть заплыв.",
                fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(8.dp))
            LineChart(
                points = pts,
                lines = lines,
                lowerIsBetter = mode == 0,
                yLabel = { v -> if (mode == 0) formatTime((v * 100).roundToInt()) else v.roundToInt().toString() },
                selected = selIdx,
                onSelect = { sel = it },
                modifier = Modifier.fillMaxWidth().height(260.dp)
            )
        }

        GradientCard(AquaBrush) {
            Text(formatDate(selR.epochDay), color = Color.White.copy(alpha = 0.9f), fontSize = 12.sp)
            Text(formatTime(selR.timeCs), color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Text(
                "Очки: ${vm.points(selR) ?: "—"} · Разряд: ${rankText(vm.rank(selR))}",
                color = Color.White, fontWeight = FontWeight.SemiBold
            )
            if (selR.place.isNotBlank()) Text(selR.place, color = Color.White.copy(alpha = 0.9f), fontSize = 12.sp)
        }

        val best = list.minBy { it.timeCs }
        val firstR = list.first()
        SoftCard {
            Text("Итоги по дистанции", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            StatRow("Заплывов", "${list.size}")
            StatRow("Личный рекорд", "${formatTime(best.timeCs)} (${formatDate(best.epochDay)})")
            StatRow("Среднее время", formatTime(list.map { it.timeCs }.average().roundToInt()))
            if (list.size > 1) {
                val d = firstR.timeCs - best.timeCs
                StatRow("Прогресс с первого заплыва", if (d > 0) "−${formatGap(d)}" else "без улучшения")
            }
        }
    }
}

@Composable
fun StatRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
        Text(value, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
    }
}

package ru.swimtrack.app

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AddScreen(vm: SwimViewModel, editing: SwimResult?, onDone: () -> Unit) {
    val ctx = LocalContext.current

    var pool by remember(editing) { mutableStateOf(editing?.event?.pool ?: 50) }
    var style by remember(editing) { mutableStateOf(editing?.event?.style ?: Style.FREE) }
    var dist by remember(editing) { mutableStateOf(editing?.event?.dist ?: 100) }
    var min by remember(editing) { mutableStateOf(editing?.let { (it.timeCs / 6000).toString() } ?: "") }
    var sec by remember(editing) { mutableStateOf(editing?.let { ((it.timeCs % 6000) / 100).toString() } ?: "") }
    var hun by remember(editing) { mutableStateOf(editing?.let { "%02d".format(it.timeCs % 100) } ?: "") }
    var epochDay by remember(editing) { mutableLongStateOf(editing?.epochDay ?: LocalDate.now().toEpochDay()) }
    var place by remember(editing) { mutableStateOf(editing?.place ?: "") }
    var note by remember(editing) { mutableStateOf(editing?.note ?: "") }
    var showDate by remember { mutableStateOf(false) }

    val dists = remember(pool, style) { vm.tables.distances(pool, style) }
    LaunchedEffect(pool, style) {
        if (dist !in dists && dists.isNotEmpty()) dist = dists.first()
    }

    val m = min.toIntOrNull() ?: 0
    val s = sec.toIntOrNull() ?: 0
    val h = hun.padEnd(2, '0').toIntOrNull() ?: 0
    val cs = m * 6000 + s * 100 + h
    val valid = cs > 0 && s < 60
    val event = EventKey(pool, style, dist)
    val points = if (valid) vm.tables.points(vm.sex, event, cs) else null
    val rankIdx = if (valid) vm.tables.rankIndex(vm.sex, event, cs) else null

    Column(
        Modifier
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            if (editing == null) "Новый заплыв" else "Редактирование заплыва",
            fontSize = 24.sp, fontWeight = FontWeight.Bold
        )

        SoftCard {
            Text("Бассейн", fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(25, 50).forEach { p ->
                    FilterChip(selected = pool == p, onClick = { pool = p }, label = { Text("$p м") })
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("Стиль", fontWeight = FontWeight.SemiBold)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Style.entries.forEach { st ->
                    FilterChip(selected = style == st, onClick = { style = st }, label = { Text(st.ru) })
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("Дистанция", fontWeight = FontWeight.SemiBold)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                dists.forEach { d ->
                    FilterChip(selected = dist == d, onClick = { dist = d }, label = { Text("$d м") })
                }
            }
        }

        SoftCard {
            Text("Время", fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = min, onValueChange = { min = it.filter(Char::isDigit).take(2) },
                    label = { Text("мин") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = sec, onValueChange = { sec = it.filter(Char::isDigit).take(2) },
                    label = { Text("сек") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = hun, onValueChange = { hun = it.filter(Char::isDigit).take(2) },
                    label = { Text("сотые") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f)
                )
            }
            if (sec.isNotEmpty() && s >= 60) {
                Text("Секунды должны быть меньше 60", color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
            }
        }

        if (valid) {
            GradientCard(if (rankIdx != null && rankIdx >= 0) VioletBrush else AquaBrush) {
                Text(formatTime(cs), color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                Text(event.full, color = Color.White.copy(alpha = 0.9f), fontSize = 13.sp)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Очки: ${points ?: "—"}   ·   Разряд: ${rankText(rankIdx)}",
                    color = Color.White, fontWeight = FontWeight.SemiBold
                )
                if (rankIdx == null) {
                    Text(
                        "Для этой дистанции в таблице ЕВСК нет норматива",
                        color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp
                    )
                }
            }
        }

        SoftCard {
            OutlinedButton(onClick = { showDate = true }, modifier = Modifier.fillMaxWidth()) {
                Text("Дата: ${formatDate(epochDay)}")
            }
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = place, onValueChange = { place = it.take(60) },
                label = { Text("Соревнование / место") }, singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = note, onValueChange = { note = it.take(300) },
                label = { Text("Заметка") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        Button(
            onClick = {
                val r = SwimResult(
                    id = editing?.id ?: System.currentTimeMillis(),
                    epochDay = epochDay,
                    event = event,
                    timeCs = cs,
                    place = place.trim(),
                    note = note.trim()
                )
                if (editing != null) vm.update(r) else vm.add(r)
                Toast.makeText(ctx, "Сохранено", Toast.LENGTH_SHORT).show()
                if (editing == null) {
                    min = ""; sec = ""; hun = ""; place = ""; note = ""
                }
                onDone()
            },
            enabled = valid,
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (editing == null) "Сохранить заплыв" else "Сохранить изменения") }
    }

    if (showDate) {
        val st = rememberDatePickerState(initialSelectedDateMillis = epochDay * 86_400_000L)
        DatePickerDialog(
            onDismissRequest = { showDate = false },
            confirmButton = {
                TextButton(onClick = {
                    st.selectedDateMillis?.let { epochDay = it / 86_400_000L }
                    showDate = false
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { showDate = false }) { Text("Отмена") } }
        ) { DatePicker(state = st) }
    }
}

package ru.swimtrack.app

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val LightColors = lightColorScheme(
    primary = Color(0xFF0A7CFF),
    onPrimary = Color.White,
    secondary = Color(0xFF00BFA6),
    tertiary = Color(0xFF8B5CF6),
    background = Color(0xFFEFF6FF),
    onBackground = Color(0xFF0B1B33),
    surface = Color.White,
    onSurface = Color(0xFF0B1B33),
    surfaceVariant = Color(0xFFDCEBFF),
    onSurfaceVariant = Color(0xFF3B4A63),
    primaryContainer = Color(0xFFD6E8FF),
    onPrimaryContainer = Color(0xFF002B66),
    secondaryContainer = Color(0xFFCFF7F0),
    onSecondaryContainer = Color(0xFF00403A),
    outline = Color(0xFF9DB2D0)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF5AAEFF),
    onPrimary = Color(0xFF00213F),
    secondary = Color(0xFF3DE0C8),
    tertiary = Color(0xFFB69CFF),
    background = Color(0xFF08121F),
    onBackground = Color(0xFFE6EEFB),
    surface = Color(0xFF111E30),
    onSurface = Color(0xFFE6EEFB),
    surfaceVariant = Color(0xFF1C2B42),
    onSurfaceVariant = Color(0xFFB4C2D9),
    primaryContainer = Color(0xFF123A6B),
    onPrimaryContainer = Color(0xFFD6E8FF),
    secondaryContainer = Color(0xFF0E4B44),
    onSecondaryContainer = Color(0xFFCFF7F0),
    outline = Color(0xFF5A6E8C)
)

val AquaBrush = Brush.linearGradient(listOf(Color(0xFF22D3EE), Color(0xFF2563EB)))
val SunsetBrush = Brush.linearGradient(listOf(Color(0xFFFF9A44), Color(0xFFFF4E8A)))
val VioletBrush = Brush.linearGradient(listOf(Color(0xFFB06AFF), Color(0xFF5B5BFF)))
val MintBrush = Brush.linearGradient(listOf(Color(0xFF34E0A1), Color(0xFF0BA6C9)))

fun rankColor(idx: Int?): Color = when (idx) {
    null -> Color(0xFF9AA7BA)
    -1 -> Color(0xFF9AA7BA)
    0 -> Color(0xFFE6A800)
    1 -> Color(0xFFFF8A00)
    2 -> Color(0xFFFF5A36)
    3 -> Color(0xFF8B5CF6)
    4 -> Color(0xFF3D7BFF)
    5 -> Color(0xFF00A9C7)
    6 -> Color(0xFF1FA38F)
    7 -> Color(0xFF55B05A)
    else -> Color(0xFF8D99AB)
}

@Composable
fun SwimTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        content = content
    )
}

@Composable
fun GradientCard(
    brush: Brush,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Box(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(brush)
            .padding(18.dp)
    ) {
        Column(content = content)
    }
}

@Composable
fun SoftCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier
            .fillMaxWidth()
            .let { if (onClick != null) it.clip(RoundedCornerShape(20.dp)).clickable { onClick() } else it }
    ) {
        Column(Modifier.padding(16.dp), content = content)
    }
}

@Composable
fun RankChip(text: String, color: Color, modifier: Modifier = Modifier) {
    Surface(color = color.copy(alpha = 0.16f), shape = CircleShape, modifier = modifier) {
        Text(
            text,
            color = color,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}

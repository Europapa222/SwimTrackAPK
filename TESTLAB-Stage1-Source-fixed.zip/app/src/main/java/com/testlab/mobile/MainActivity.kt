package com.testlab.mobile

import android.content.*
import android.os.*
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.navigation.compose.*
import androidx.navigation.NavGraph.Companion.findStartDestination

data class Battery(val percent:Int?=null,val plugged:Boolean?=null,val charging:Boolean?=null)
data class Tool(val name:String,val summary:String,val icon:String,val color:Color,val details:String,val limits:String)
val tools = listOf(
    Tool("Зарядка","Скорость и мощность","bolt",Color(0xFFAA8BFF),"Мощность, ток и стабильность зарядки.","Потребуются данные контроллера батареи. Не все модели сообщают ток и напряжение."),
    Tool("Аккумулятор","Состояние и износ","battery",Color(0xFF62DFA1),"Уровень заряда, температура и оценка состояния батареи.","Реальная ёмкость и износ доступны не на всех устройствах."),
    Tool("Интернет","Скорость и стабильность","wifi",Color(0xFF899BFF),"Скорость передачи, задержка и стабильность соединения.","Для измерений потребуется активное сетевое соединение."),
    Tool("Аудио","Задержка и качество","audio",Color(0xFFC68BFF),"Исследование задержки воспроизведения звука.","Точные акустические измерения могут требовать внешнего оборудования."),
    Tool("Освещение","Мерцание и яркость","light",Color(0xFFFFCB66),"Анализ доступных показаний датчика света.","Частота опроса датчика зависит от телефона; измерение ШИМ не гарантируется.")
)
data class TestResult(val title:String,val timestamp:Long,val summary:String)
interface ResultRepository { fun results():List<TestResult> }
object EmptyResultRepository:ResultRepository { override fun results()=emptyList<TestResult>() }

class MainActivity:ComponentActivity(){
    private var battery by mutableStateOf(Battery())
    private val receiver=object:BroadcastReceiver(){override fun onReceive(context:Context?,intent:Intent?){
        if(intent==null)return
        val level=intent.getIntExtra(BatteryManager.EXTRA_LEVEL,-1); val scale=intent.getIntExtra(BatteryManager.EXTRA_SCALE,-1)
        val plug=intent.getIntExtra(BatteryManager.EXTRA_PLUGGED,-1); val status=intent.getIntExtra(BatteryManager.EXTRA_STATUS,-1)
        battery=Battery(if(level>=0&&scale>0)(level*100/scale).coerceIn(0,100) else null,if(plug>=0)plug!=0 else null,if(status>=0)status==BatteryManager.BATTERY_STATUS_CHARGING else null)
    }}
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState)
        val prefs=getSharedPreferences("settings",MODE_PRIVATE)
        setContent { var mode by rememberSaveable { mutableStateOf(prefs.getString("theme","system")?:"system") }; val dark=when(mode){"dark"->true;"light"->false;else->isSystemInDarkTheme()}
            val colors=if(dark) darkColorScheme(primary=Color(0xFFB18AFF),background=Color(0xFF0C0D12),surface=Color(0xFF191923),surfaceVariant=Color(0xFF262432),onBackground=Color(0xFFF5F5F8),onSurface=Color(0xFFF5F5F8),onSurfaceVariant=Color(0xFFACADBF)) else lightColorScheme(primary=Color(0xFF7343CA),background=Color(0xFFF6F5FA),surface=Color.White,surfaceVariant=Color(0xFFEAE6F4),onBackground=Color(0xFF161421),onSurface=Color(0xFF161421),onSurfaceVariant=Color(0xFF615C72))
            SideEffect { window.statusBarColor=colors.background.toArgb();window.navigationBarColor=colors.background.toArgb();window.decorView.systemUiVisibility=if(dark)0 else android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR }
            MaterialTheme(colorScheme=colors){ Lab(battery,mode){mode=it;prefs.edit().putString("theme",it).apply()} }
        }
    }
    override fun onStart(){super.onStart();registerReceiver(receiver,IntentFilter(Intent.ACTION_BATTERY_CHANGED))}
    override fun onStop(){unregisterReceiver(receiver);super.onStop()}
}
@Composable fun Glyph(kind:String,color:Color,modifier:Modifier=Modifier.size(28.dp)){
    Canvas(modifier){val w=size.width;val h=size.height;val s=w/12;fun p(x:Float,y:Float)=Offset(x*w/24,y*h/24)
        fun line(a:Offset,b:Offset)=drawLine(color,a,b,s,StrokeCap.Round)
        fun path(vararg pts:Pair<Float,Float>){val q=Path();pts.forEachIndexed{i,v->if(i==0)q.moveTo(v.first*w/24,v.second*h/24) else q.lineTo(v.first*w/24,v.second*h/24)};drawPath(q,color,style=Stroke(s,cap=StrokeCap.Round,join=StrokeJoin.Round))}
        when(kind){
            "bolt"->path(13f to 2f,4f to 13f,11f to 13f,10f to 22f,20f to 10f,13f to 10f,13f to 2f)
            "battery"->{drawRoundRect(color, p(3f,6f), androidx.compose.ui.geometry.Size(w*17/24,h*12/24),androidx.compose.ui.geometry.CornerRadius(s),style=Stroke(s));line(p(22f,10f),p(22f,14f));drawRoundRect(color,p(6f,9f),androidx.compose.ui.geometry.Size(w*11/24,h*6/24),androidx.compose.ui.geometry.CornerRadius(s/2))}
            "wifi"->{for(i in 0..2){val r=w*(.47f-i*.14f);drawArc(color,220f,100f,false,Offset(w/2-r,h*.78f-r),androidx.compose.ui.geometry.Size(r*2,r*2),style=Stroke(s,cap=StrokeCap.Round))};drawCircle(color,s/1.3f,p(12f,19f))}
            "audio"->{drawArc(color,180f,180f,false,p(3f,3f),androidx.compose.ui.geometry.Size(w*.75f,h*.75f),style=Stroke(s));path(3f to 12f,3f to 20f,7f to 20f,7f to 13f);path(21f to 12f,21f to 20f,17f to 20f,17f to 13f)}
            "light"->{drawCircle(color,w*.29f,p(12f,9f),style=Stroke(s));line(p(9f,18f),p(15f,18f));line(p(10f,21f),p(14f,21f))}
            "home"->path(2f to 11f,12f to 3f,22f to 11f,19f to 11f,19f to 21f,14f to 21f,14f to 15f,10f to 15f,10f to 21f,5f to 21f,5f to 11f)
            "history"->{drawCircle(color,w*.4f,p(12f,12f),style=Stroke(s));path(12f to 6f,12f to 12f,17f to 15f)}
            "settings"->{drawCircle(color,w*.32f,p(12f,12f),style=Stroke(s));drawCircle(color,w*.12f,p(12f,12f),style=Stroke(s));for(i in 0..7){val a=i*Math.PI/4;val x=kotlin.math.cos(a).toFloat();val y=kotlin.math.sin(a).toFloat();line(Offset(w/2+x*w*.32f,h/2+y*h*.32f),Offset(w/2+x*w*.46f,h/2+y*h*.46f))}}
            "tools"->{path(4f to 20f,17f to 7f,16f to 3f,20f to 3f,22f to 7f,21f to 11f,17f to 12f,7f to 22f,4f to 20f);line(p(3f,3f),p(10f,10f))}
            "phone"->{drawRoundRect(color,p(6f,2f),androidx.compose.ui.geometry.Size(w*.5f,h*.83f),androidx.compose.ui.geometry.CornerRadius(s*2),style=Stroke(s));line(p(10f,18f),p(14f,18f))}
            else->{path(8f to 3f,16f to 3f,14f to 3f,14f to 10f,21f to 20f,20f to 22f,4f to 22f,3f to 20f,10f to 10f,10f to 3f);line(p(7f,16f),p(17f,16f));drawCircle(color,s/2,p(17f,5f))}
        }
    }
}
@Composable fun CardBox(modifier:Modifier=Modifier,onClick:(()->Unit)?=null,content:@Composable ColumnScope.()->Unit){val shape=RoundedCornerShape(18.dp);Column(modifier.clip(shape).background(MaterialTheme.colorScheme.surface).then(if(onClick!=null)Modifier.clickable(onClick=onClick) else Modifier).padding(16.dp),content=content)}
@Composable fun Title(text:String){Text(text,fontSize=26.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.onBackground)}
@Composable fun Sub(text:String,modifier:Modifier=Modifier){Text(text,modifier,color=MaterialTheme.colorScheme.onSurfaceVariant,fontSize=13.sp,lineHeight=19.sp)}
@Composable fun Action(text:String,click:()->Unit){Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).background(Brush.horizontalGradient(listOf(Color(0xFF9A66EF),Color(0xFF7144D9)))).clickable(onClick=click).padding(17.dp),contentAlignment=Alignment.Center){Text(text,color=Color.White,fontWeight=FontWeight.SemiBold,fontSize=16.sp)}}
@Composable fun Badge(){Text("В разработке",Modifier.clip(RoundedCornerShape(20.dp)).background(MaterialTheme.colorScheme.surfaceVariant).padding(horizontal=9.dp,vertical=4.dp),color=MaterialTheme.colorScheme.primary,fontSize=11.sp,fontWeight=FontWeight.Medium)}
@Composable fun Lab(battery:Battery,mode:String,onTheme:(String)->Unit){val nav=rememberNavController();val entry by nav.currentBackStackEntryAsState();val route=entry?.destination?.route?:"home";val tabs=listOf("home" to "Главная","tools" to "Инструменты","history" to "История","settings" to "Настройки")
    fun go(r:String){nav.navigate(r){popUpTo(nav.graph.findStartDestination().id){saveState=true};launchSingleTop=true;restoreState=true}}
    Scaffold(containerColor=MaterialTheme.colorScheme.background,bottomBar={Surface(color=MaterialTheme.colorScheme.surface,shape=RoundedCornerShape(topStart=24.dp,topEnd=24.dp)){Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(vertical=9.dp),horizontalArrangement=Arrangement.SpaceEvenly){tabs.forEach{(r,label)->val active=route==r||r=="tools"&&route.startsWith("detail");val color by animateColorAsState(if(active)MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,tween(220),label="tab");Column(Modifier.weight(1f).clickable{go(r)}.padding(vertical=7.dp),horizontalAlignment=Alignment.CenterHorizontally){Glyph(r,color,Modifier.size(24.dp));Spacer(Modifier.height(5.dp));Text(label,color=color,fontSize=10.sp,fontWeight=if(active)FontWeight.Bold else FontWeight.Normal)}}}}}){padding->
        NavHost(navController=nav,startDestination="home",modifier=Modifier.padding(padding),enterTransition={fadeIn(tween(220))},exitTransition={fadeOut(tween(180))}){
            composable("home"){Home(battery,{go("tools")},{go("settings")},{nav.navigate("detail/$it")})}
            composable("tools"){Catalog{nav.navigate("detail/$it")}}
            composable("history"){History{go("tools")}}
            composable("settings"){Settings(mode,onTheme)}
            composable("detail/{index}"){val i=it.arguments?.getString("index")?.toIntOrNull()?:0;Detail(tools[i.coerceIn(tools.indices)]){nav.popBackStack()}}
        }
    }
}
@Composable fun Page(content:@Composable ColumnScope.()->Unit){Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal=20.dp,vertical=20.dp),verticalArrangement=Arrangement.spacedBy(12.dp),content=content)}
@Composable fun Home(b:Battery,open:()->Unit,settings:()->Unit,detail:(Int)->Unit){Page{
    Row(verticalAlignment=Alignment.CenterVertically){Glyph("flask",MaterialTheme.colorScheme.primary);Spacer(Modifier.width(10.dp));Text("TESTLAB",fontWeight=FontWeight.Black,fontSize=22.sp,modifier=Modifier.weight(1f));Box(Modifier.size(48.dp).clickable(onClick=settings),contentAlignment=Alignment.Center){Glyph("settings",MaterialTheme.colorScheme.primary)}}
    Title("Твоя лаборатория");Sub("Проверяй устройства. Сравнивай результаты.")
    CardBox(Modifier.fillMaxWidth()){Row(verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(58.dp,76.dp).clip(RoundedCornerShape(12.dp)).background(Brush.linearGradient(listOf(Color(0xFF29263E),Color(0xFF6B51C8)))),contentAlignment=Alignment.Center){Glyph("phone",Color.White,Modifier.size(42.dp))};Spacer(Modifier.width(14.dp));Column(Modifier.weight(1f)){Text(Build.MODEL.ifBlank{"Неизвестная модель"},fontWeight=FontWeight.Bold,fontSize=16.sp);Sub("Android ${Build.VERSION.RELEASE}");Spacer(Modifier.height(8.dp));Row(verticalAlignment=Alignment.CenterVertically){Glyph("battery",Color(0xFF62DFA1),Modifier.size(20.dp));Spacer(Modifier.width(6.dp));Text(b.percent?.let{"$it%"}?:"—",color=MaterialTheme.colorScheme.onSurface,fontWeight=FontWeight.Bold)};Sub(when{b.charging==true->"Заряжается";b.plugged==true->"Подключено к питанию";b.plugged==false->"Не подключено";else->"Состояние неизвестно"})}}}
    Action("Новый тест",open);Text("Быстрый доступ",fontWeight=FontWeight.Bold,fontSize=18.sp)
    tools.chunked(2).forEachIndexed{row,items->Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){items.forEachIndexed{col,t->CardBox(Modifier.weight(1f),{detail(row*2+col)}){Glyph(t.icon,t.color);Spacer(Modifier.height(7.dp));Text(t.name,fontWeight=FontWeight.SemiBold);Sub(t.summary);Spacer(Modifier.height(6.dp));Badge()}};if(items.size==1)Spacer(Modifier.weight(1f))}}
    Text("Последние результаты",fontSize=18.sp,fontWeight=FontWeight.Bold);CardBox(Modifier.fillMaxWidth()){Sub("Результатов пока нет. Здесь появятся завершённые проверки.")}
}}
@Composable fun Catalog(detail:(Int)->Unit){var query by rememberSaveable{mutableStateOf("")};Page{Title("Инструменты");OutlinedTextField(query,{query=it},modifier=Modifier.fillMaxWidth(),singleLine=true,placeholder={Text("Поиск инструмента…")},shape=RoundedCornerShape(15.dp));val filtered=tools.withIndex().filter{it.value.name.contains(query.trim(),true)};if(filtered.isEmpty())Sub("Инструменты не найдены");filtered.forEach{(i,t)->CardBox(Modifier.fillMaxWidth(),{detail(i)}){Row(verticalAlignment=Alignment.CenterVertically){Glyph(t.icon,t.color,Modifier.size(35.dp));Spacer(Modifier.width(14.dp));Column(Modifier.weight(1f)){Text(t.name,fontWeight=FontWeight.Bold);Sub(t.summary);Spacer(Modifier.height(7.dp));Badge()};Text("›",fontSize=26.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)}}}}}
@Composable fun Detail(t:Tool,back:()->Unit){Page{TextButton(onClick=back){Text("‹ Назад")};Glyph(t.icon,t.color,Modifier.size(58.dp));Title(t.name);Badge();CardBox(Modifier.fillMaxWidth()){Text("Что будет измеряться",fontWeight=FontWeight.Bold);Spacer(Modifier.height(8.dp));Sub(t.details)};CardBox(Modifier.fillMaxWidth()){Text("Возможности и ограничения",fontWeight=FontWeight.Bold);Spacer(Modifier.height(8.dp));Sub(t.limits)};Sub("Этот инструмент пока недоступен. Реальные измерения появятся в следующем этапе разработки.")}}
@Composable fun History(open:()->Unit){Column(Modifier.fillMaxSize().padding(20.dp)){Title("История");Column(Modifier.weight(1f).fillMaxWidth(),verticalArrangement=Arrangement.Center,horizontalAlignment=Alignment.CenterHorizontally){Glyph("flask",MaterialTheme.colorScheme.primary,Modifier.size(100.dp));Spacer(Modifier.height(26.dp));Text("Пока нет результатов",fontSize=20.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(10.dp));Sub("Здесь будут храниться результаты всех твоих тестов.");Spacer(Modifier.height(28.dp));Action("Выбрать инструмент",open)}}}
@Composable fun Settings(mode:String,onTheme:(String)->Unit){var dialog by rememberSaveable{mutableStateOf("")};Page{Title("Настройки");Text("Тема оформления",fontWeight=FontWeight.Bold,fontSize=18.sp);CardBox(Modifier.fillMaxWidth()){listOf("system" to "Как в системе","light" to "Светлая","dark" to "Тёмная").forEach{(id,label)->Row(Modifier.fillMaxWidth().clickable{onTheme(id)},verticalAlignment=Alignment.CenterVertically){Text(label,Modifier.weight(1f));RadioButton(mode==id,{onTheme(id)})};if(id!="dark")HorizontalDivider(color=MaterialTheme.colorScheme.surfaceVariant)}};CardBox(Modifier.fillMaxWidth()){listOf("О приложении","Конфиденциальность").forEach{label->Row(Modifier.fillMaxWidth().clickable{dialog=label}.padding(vertical=12.dp),verticalAlignment=Alignment.CenterVertically){Text(label,Modifier.weight(1f));Text("›",fontSize=24.sp)};HorizontalDivider(color=MaterialTheme.colorScheme.surfaceVariant)};Spacer(Modifier.height(12.dp));Text("Версия приложения",fontWeight=FontWeight.SemiBold);Sub("v0.1 (beta)")}};if(dialog.isNotEmpty())AlertDialog(onDismissRequest={dialog=""},title={Text(dialog)},text={Text(if(dialog=="О приложении")"TESTLAB — твоя лаборатория. Не верь характеристикам. Проверяй." else "TESTLAB не требует аккаунта, не отправляет данные и не содержит аналитики. Настройки хранятся только на устройстве.")},confirmButton={TextButton(onClick={dialog=""}){Text("Понятно")}})}
